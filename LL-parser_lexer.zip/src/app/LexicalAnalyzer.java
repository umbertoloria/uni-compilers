package app;

import app.state.IState;
import app.state.PreInitialState;

import java.io.IOException;

public class LexicalAnalyzer {

	private MyFileReader fileReader;
	private SymbolsTable symbolsTable;

	public void initialize(String filePath) throws IOException {
		fileReader = new MyFileReader(filePath);
		symbolsTable = new SymbolsTable();
	}

	public Token nextToken() throws Exception {
		IState state = new PreInitialState(this);

		int read;
		char c;
		StringBuilder lex = new StringBuilder();

		while (state.getToken() == null) {
			read = fileReader.nextChar();
			if (read == -1)
				break;

			c = (char) read;
			try {
				state.process(c, lex);
			} catch (RuntimeException e) {
				throw new RuntimeException(e.getMessage() + " - " + fileReader.createLocalizedErrorMessage());
			}

			state = state.getNextState();
		}
		if (state.getToken() == null) {
			try {
				state.process(' ', lex);
			} catch (RuntimeException e) {
				throw new RuntimeException(e.getMessage() + " - " + fileReader.createLocalizedErrorMessage());
			}
		}
		return state.getToken();
	}

	// UTILS

	public void retract() throws IOException {
		fileReader.retract();
	}

	public Token installId(String lessema) {
		return symbolsTable.installId(lessema);
	}

	public Token installNum(String num) {
		return symbolsTable.installNum(num);
	}

}
