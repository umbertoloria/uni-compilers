package app;

public class SymbolTracker {

	private int row = 1;
	private int col = 0;
	private int prevRowMaxCol = 0;

	public void newChar() {
		col++;
	}

	public void newLine() {
		row++;
		prevRowMaxCol = col;
		col = 0;
	}

	public void retractChar() {
		if (col > 0)
			col--;
		else if (row > 1) {
			row--;
			col = prevRowMaxCol;
		}
	}

	public int getRow() {
		return row;
	}

	public int getCol() {
		return col;
	}
}
