package app;

public class Token {

	public final String name;
	public final String attribute;

	public Token(String name, String attribute) {
		this.name = name;
		this.attribute = attribute;
	}

	public Token(String name) {
		this.name = name;
		this.attribute = null;
	}

	public String toString() {
		String result = "<" + name;
		if (attribute != null)
			result += ",\"" + attribute + "\"";
		result += ">";
		return result;
	}

}
