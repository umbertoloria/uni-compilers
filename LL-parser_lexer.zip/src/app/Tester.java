package app;

import parser.Parser;

import java.util.ArrayList;
import java.util.List;

public class Tester {

	public static void main(String[] args) {
		LexicalAnalyzer lexicalAnalyzer = new LexicalAnalyzer();
		try {
			List<Token> tokens = new ArrayList<>();
			lexicalAnalyzer.initialize(args[0]);
			Token token = lexicalAnalyzer.nextToken();
			while (token != null) {
				tokens.add(token);
				token = lexicalAnalyzer.nextToken();
			}
			tokens.add(new Token("EOF"));
			Parser parser = new Parser();
			parser.parse(tokens, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
