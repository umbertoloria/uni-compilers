package app.state;

import java.io.IOException;

public class IntState extends BaseState {

	public IntState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) throws IOException {
		if (Character.isDigit(c)) {
			str.append(c);
		} else if (c == '.') {
			str.append(c);
			nextState = new RealState(this);
		} else {
			retract();
			token = installNum(str.toString());
		}
	}

}
