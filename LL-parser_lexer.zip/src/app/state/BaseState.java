package app.state;

import app.LexicalAnalyzer;
import app.Token;

import java.io.IOException;

public abstract class BaseState implements IState {

	protected IState nextState;
	protected Token token;
	private final LexicalAnalyzer lexicalAnalyzer;

	protected BaseState(LexicalAnalyzer lexicalAnalyzer) {
		this.nextState = this;
		this.token = null;
		this.lexicalAnalyzer = lexicalAnalyzer;
	}

	protected BaseState(BaseState prev) {
		this.nextState = this;
		this.token = null;
		this.lexicalAnalyzer = prev.lexicalAnalyzer;
	}

	public Token getToken() {
		return token;
	}

	public IState getNextState() {
		return nextState;
	}

	// Delegations

	protected void retract() throws IOException {
		lexicalAnalyzer.retract();
	}

	protected Token installId(String lessema) {
		return lexicalAnalyzer.installId(lessema);
	}

	protected Token installNum(String num) {
		return lexicalAnalyzer.installNum(num);
	}

}
