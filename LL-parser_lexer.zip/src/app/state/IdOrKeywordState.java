package app.state;

import java.io.IOException;

public class IdOrKeywordState extends BaseState {

	public IdOrKeywordState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) throws IOException {
		if (Character.isLetter(c) || c == '_') {
			str.append(c);
		} else {
			retract();
			token = installId(str.toString());
		}
	}

}
