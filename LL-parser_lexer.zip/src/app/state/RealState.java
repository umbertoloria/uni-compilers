package app.state;

import java.io.IOException;

public class RealState extends BaseState {

	public RealState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) throws IOException {
		if (Character.isDigit(c)) {
			str.append(c);
		} else if (c == '.') {
			throw new RuntimeException("troppi . in un float");
		} else {
			retract();
			token = installNum(str.toString());
		}
	}

}
