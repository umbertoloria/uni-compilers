package app.state;

import app.Token;

public class EqualComparisonState extends BaseState {

	public EqualComparisonState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) {
		if (c == '=') {
			str.append(c);
			token = new Token("EQUALCOMPARISON");
		} else {
			throw new RuntimeException("il simbolo = è sempre doppio");
		}
	}

}
