package app.state;

import app.Token;

public class NotEqualComparisonState extends BaseState {

	public NotEqualComparisonState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) {
		if (c == '=') {
			str.append(c);
			token = new Token("NOTEQUALCOMPARISON");
		} else {
			throw new RuntimeException("il simbolo = segue sempre !");
		}
	}

}
