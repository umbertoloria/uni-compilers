package app.state;

import app.LexicalAnalyzer;
import app.Token;

import java.io.IOException;

/**
 This pre-initial state has the only purpose to skit the initial syntactic sugar */
public class PreInitialState extends BaseState {

	public PreInitialState(LexicalAnalyzer lexicalAnalyzer) {
		super(lexicalAnalyzer);
	}

	public void process(char c, StringBuilder str) throws IOException {
		if (c != ' ' && c != '\r' && c != '\n' && c != '\t') {
			retract();
			nextState = new InitialState(this);
		}
	}

	public Token getToken() {
		return null;
	}

	public IState getNextState() {
		return nextState;
	}

}
