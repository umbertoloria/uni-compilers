package app.state;

import app.Token;

import java.io.IOException;

public class GreaterOrGreaterequalState extends BaseState {

	public GreaterOrGreaterequalState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) throws IOException {
		if (c == '=') {
			str.append(c);
			token = new Token("GREATEREQUALOF");
		} else {
			retract();
			token = new Token("GREATEROF");
		}
	}

}
