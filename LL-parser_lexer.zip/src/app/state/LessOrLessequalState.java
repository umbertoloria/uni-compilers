package app.state;

import app.Token;

import java.io.IOException;

public class LessOrLessequalState extends BaseState {

	public LessOrLessequalState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) throws IOException {
		if (c == '=') {
			str.append(c);
			token = new Token("LESSEQUALOF");
		} else {
			retract();
			token = new Token("LESSOF");
		}
	}

}
