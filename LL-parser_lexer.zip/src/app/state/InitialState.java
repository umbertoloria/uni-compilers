package app.state;

import app.Token;

public class InitialState extends BaseState {

	public InitialState(BaseState prev) {
		super(prev);
	}

	public void process(char c, StringBuilder str) {
		str.append(c);
		if (Character.isLetter(c)) {
			nextState = new IdOrKeywordState(this);
		} else if (Character.isDigit(c) || c == '-') {
			nextState = new IntState(this);
		} else if (c == '<') {
			nextState = new LessOrLessequalState(this);
		} else if (c == '>') {
			nextState = new GreaterOrGreaterequalState(this);
		} else if (c == '=') {
			nextState = new EqualComparisonState(this);
		} else if (c == '!') {
			nextState = new NotEqualComparisonState(this);
		} else if (c == '.') {
			nextState = new RealState(this);
		} else if (c == '+') {
			token = new Token("PLUS");
		} else if (c == '(') {
			token = new Token("OPEN_BRACKET");
		} else if (c == ')') {
			token = new Token("CLOSE_BRACKET");
		} else if (c == ',') {
			token = new Token("COMA");
		} else {
			throw new RuntimeException("carattere inaspettato (sono InitialState) = " + c + "(" + ((int) c) + ")");
		}
	}

}
