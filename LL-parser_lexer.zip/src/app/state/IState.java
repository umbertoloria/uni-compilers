package app.state;

import app.Token;

import java.io.IOException;

public interface IState {

	void process(char c, StringBuilder str) throws IOException;

	Token getToken();

	IState getNextState();

}
