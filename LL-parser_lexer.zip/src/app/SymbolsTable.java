package app;

import java.util.HashMap;
import java.util.Map;

public class SymbolsTable {

	private final Map<String, Token> keywords = new HashMap<>();
	private final Map<String, Token> table = new HashMap<>();

	public SymbolsTable() {
		keywords.put("func", new Token("FUNC"));
		keywords.put("endfunc", new Token("ENDFUNC"));
		keywords.put("if", new Token("IF"));
		keywords.put("then", new Token("THEN"));
		keywords.put("else", new Token("ELSE"));
		keywords.put("endif", new Token("ENDIF"));
		keywords.put("while", new Token("WHILE"));
		keywords.put("endwhile", new Token("ENDWHILE"));
		keywords.put("for", new Token("FOR"));
		keywords.put("return", new Token("RETURN"));
		keywords.put("int", new Token("INT"));
		keywords.put("float", new Token("FLOAT"));
		keywords.put("bool", new Token("BOOL"));
		keywords.put("main", new Token("MAIN"));
		keywords.put("endmain", new Token("ENDMAIN"));
		keywords.put("is", new Token("IS"));
	}

	public Token installId(String lessema) {
		if (keywords.containsKey(lessema.toLowerCase())) {
			return keywords.get(lessema.toLowerCase());
		} else if (table.containsKey(lessema)) {
			return table.get(lessema);
		} else {
			Token token = new Token("ID", lessema);
			table.put(lessema, token);
			return token;
		}
	}

	public Token installNum(String lessema) {
		if (table.containsKey(lessema)) {
			return table.get(lessema);
		} else {
			Token token = new Token("NUM", lessema);
			table.put(lessema, token);
			return token;
		}
	}

}
