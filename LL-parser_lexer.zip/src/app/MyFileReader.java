package app;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class MyFileReader {

	private final FileInputStream inputStream;
	private final SymbolTracker es = new SymbolTracker();
	private boolean completed = false;

	public MyFileReader(String filePath) throws IOException {
		File input = new File(filePath);
		if (!input.exists() || !input.canRead() || !input.isFile()) {
			throw new RuntimeException("Unable to read the source file");
		}
		inputStream = new FileInputStream(input);
	}

	public int nextChar() throws IOException {
		int read = inputStream.read();
		if (read >= 0) {
			es.newChar();
			if ((char) read == '\n')
				es.newLine();
		} else {
			completed = true;
		}
		return read;
	}

	public void retract() throws IOException {
		if (completed)
			return;
		long curPosition = inputStream.getChannel().position();
		if (curPosition > 0) {
			inputStream.getChannel().position(curPosition - 1);
			es.retractChar();
		}
	}

	public String createLocalizedErrorMessage() {
		return "linea " + es.getRow() + " colonna " + es.getCol();
	}
}
