package parser;

import app.Token;

import java.util.List;

/*

/////////////////// GRAMMATICA ///////////////////

S -> Program EOF
Program -> Stmt Program'
Program' -> Stmt Program'
Program' -> ''
Stmt -> IF Expr THEN Stmt ELSE Stmt ENDIF
Stmt -> ID IS Expr
Stmt -> WHILE Expr Stmt ENDWHILE
Expr -> F Expr'
Expr' -> Relop F Expr'
Expr' -> ''
F -> ID
F -> NUM
Relop -> <
Relop -> <=
Relop -> >
Relop -> >=
Relop -> ==
Relop -> !=

 */
public class Parser {

	private Token[] tokens;
	private int ptr, i;
	private boolean verboose;

	public void parse(List<Token> tokens, boolean verboose) {
		this.tokens = tokens.toArray(new Token[0]);
		this.verboose = verboose;
		ptr = 0;
		i = 0;
		s();
	}

	private void burnChar() {
		System.out.print(tokens[ptr].toString() + ' ');
		if (++i == 10) {
			i = 0;
			System.out.println();
		}
		ptr++;
	}

	private void insideNewState(String program) {
		if (verboose)
			System.out.println("        -> " + program);
	}

	private void s() {
		if (tokens[ptr].name.equals("IF") || tokens[ptr].name.equals("ID") || tokens[ptr].name.equals("WHILE")) {
			program();
			if (tokens[ptr].name.equals("EOF")) {
				burnChar();
				return;
			}
		}
		throw new IllegalStateException();
	}

	private void program() {
		insideNewState("program");
		if (tokens[ptr].name.equals("IF") || tokens[ptr].name.equals("ID") || tokens[ptr].name.equals("WHILE")) {
			stmt();
			program_();
			return;
		}
		throw new IllegalStateException();
	}

	private void program_() {
		insideNewState("program'");
		if (tokens[ptr].name.equals("IF") || tokens[ptr].name.equals("ID") || tokens[ptr].name.equals("WHILE")) {
			stmt();
			program_();
			return;
		} else if (tokens[ptr].name.equals("EOF")) {
			return;
		}
		throw new IllegalStateException();
	}

	private void stmt() {
		insideNewState("stmt");
		if (tokens[ptr].name.equals("IF")) {
			burnChar();
			expr();
			if (tokens[ptr].name.equals("THEN")) {
				burnChar();
				stmt();
				if (tokens[ptr].name.equals("ELSE")) {
					burnChar();
					stmt();
					if (tokens[ptr].name.equals("ENDIF")) {
						burnChar();
						return;
					}
				}
			}
		} else if (tokens[ptr].name.equals("ID")) {
			burnChar();
			if (tokens[ptr].name.equals("IS")) {
				burnChar();
				expr();
				return;
			}
		} else if (tokens[ptr].name.equals("WHILE")) {
			burnChar();
			expr();
			stmt();
			if (tokens[ptr].name.equals("ENDWHILE")) {
				burnChar();
				return;
			}
		}
		throw new IllegalStateException();
	}

	private void expr() {
		insideNewState("expr");
		if (tokens[ptr].name.equals("ID") || tokens[ptr].name.equals("NUM")) {
			f();
			expr_();
			return;
		}
		throw new IllegalStateException();
	}

	private void expr_() {
		insideNewState("expr'");
		if (tokens[ptr].name.equals("EOF") || tokens[ptr].name.equals("IF") || tokens[ptr].name.equals("THEN")
				|| tokens[ptr].name.equals("ELSE") || tokens[ptr].name.equals("ENDIF") || tokens[ptr].name.equals("ID")
				|| tokens[ptr].name.equals("WHILE") || tokens[ptr].name.equals("ENDWHILE")
				|| tokens[ptr].name.equals("NUM")) {
			return;
		} else if (tokens[ptr].name.equals("LESSOF") || tokens[ptr].name.equals("LESSEQUALOF")
				|| tokens[ptr].name.equals("GREATEROF") || tokens[ptr].name.equals("GREATEREQUALOF")
				|| tokens[ptr].name.equals("EQUALCOMPARISON") || tokens[ptr].name.equals("NOTEQUALCOMPARISON")) {
			relop();
			f();
			expr_();
			return;
		}
		throw new IllegalStateException();
	}

	private void f() {
		insideNewState("f");
		if (tokens[ptr].name.equals("ID") || tokens[ptr].name.equals("NUM")) {
			burnChar();
			return;
		}
		throw new IllegalStateException();
	}

	private void relop() {
		insideNewState("relop");
		if (tokens[ptr].name.equals("LESSOF") || tokens[ptr].name.equals("LESSEQUALOF")
				|| tokens[ptr].name.equals("GREATEROF") || tokens[ptr].name.equals("GREATEREQUALOF")
				|| tokens[ptr].name.equals("EQUALCOMPARISON") || tokens[ptr].name.equals("NOTEQUALCOMPARISON")) {
			burnChar();
			return;
		}
		throw new IllegalStateException();
	}

}
